package com.vms.quotify.adapter

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.vms.quotify.Blog
import com.vms.quotify.R
import java.io.OutputStream

class BlogAdapter(
    private var blogs: MutableList<Blog>,
    private val onDeleteClick: (Int) -> Unit // Callback for deletion
) : RecyclerView.Adapter<BlogAdapter.BlogViewHolder>() {

    class BlogViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgBlog: ImageView = itemView.findViewById(R.id.img_quote)
        val txtTitle: TextView = itemView.findViewById(R.id.txt_quote)
        val txtAuthor: TextView = itemView.findViewById(R.id.txt_name)
        val imgShare: ImageView = itemView.findViewById(R.id.img_share)
        val imgDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val imgDownload: ImageView = itemView.findViewById(R.id.img_download)
        val imgLike: ImageView = itemView.findViewById(R.id.img_like)
        val imgDislike: ImageView = itemView.findViewById(R.id.img_dislike)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BlogViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recycler_view, parent, false)
        return BlogViewHolder(view)
    }

    override fun onBindViewHolder(holder: BlogViewHolder, position: Int) {
        val blog = blogs[position]
        holder.imgBlog.setImageResource(blog.imageResId)
        holder.txtTitle.text = blog.title
        holder.txtAuthor.text = "- ${blog.author}"

        // Share
        holder.imgShare.setOnClickListener {
            shareBlog(holder.itemView, blog.title, blog.author)
        }

        // Delete
        holder.imgDelete.setOnClickListener {
            onDeleteClick(position)
        }

        // Like
        holder.imgLike.setOnClickListener {
            holder.imgLike.setImageDrawable(ContextCompat.getDrawable(holder.itemView.context, R.drawable.baseline_thumb_up_24))
            holder.imgDislike.setImageDrawable(ContextCompat.getDrawable(holder.itemView.context, R.drawable.outline_thumb_down_24 ))
        }

        // Dislike
        holder.imgDislike.setOnClickListener {
            holder.imgLike.setImageDrawable(ContextCompat.getDrawable(holder.itemView.context, R.drawable.outline_thumb_up_24))
            holder.imgDislike.setImageDrawable(ContextCompat.getDrawable(holder.itemView.context, R.drawable.baseline_thumb_down_24_red ))
        }

        // Download
        holder.imgDownload.setOnClickListener {
            val context = holder.itemView.context
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.READ_MEDIA_IMAGES
                ) == PackageManager.PERMISSION_GRANTED

                if (!hasPermission) {
                    Toast.makeText(context, "Permission required to save", Toast.LENGTH_SHORT).show()
                    val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = android.net.Uri.fromParts("package", context.packageName, null)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    return@setOnClickListener
                }
            }

            // Save blog title and author to a text file only
            saveTextToFile(context, blog.title, blog.author)
        }



    }

    override fun getItemCount(): Int = blogs.size

    private fun shareBlog(view: View, title: String, author: String) {
        val shareText = "$title\n\nBy: $author"
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        view.context.startActivity(Intent.createChooser(shareIntent, "Share blog via"))
    }

    fun updateData(newBlogs: MutableList<Blog>) {
        blogs = newBlogs
        notifyDataSetChanged()
    }

    fun deleteItem(position: Int) {
        blogs.removeAt(position)
        notifyItemRemoved(position)
    }

    private fun saveImageToGallery(context: Context, imageView: ImageView) {
        val drawable = imageView.drawable
        val bitmap = when (drawable) {
            is BitmapDrawable -> drawable.bitmap
            else -> {
                Toast.makeText(context, "Image is not ready yet", Toast.LENGTH_SHORT).show()
                return
            }
        }

        val filename = "quote_${System.currentTimeMillis()}.jpg"
        val resolver = context.contentResolver

        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Quotify")
        }

        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        if (imageUri == null) {
            Toast.makeText(context, "Failed to create image URI", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            resolver.openOutputStream(imageUri).use { outputStream ->
                if (outputStream == null) {
                    Toast.makeText(context, "Failed to open output stream", Toast.LENGTH_SHORT).show()
                    return
                }

                val saved = bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                if (saved) {
                    Toast.makeText(context, "Image saved to gallery", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to save image", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }


    private fun saveTextToFile(context: Context, title: String, author: String) {
        val filename = "blog_${System.currentTimeMillis()}.txt"
        val textContent = "$title\n\nBy: $author"

        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Files.FileColumns.DISPLAY_NAME, filename)
            put(MediaStore.Files.FileColumns.MIME_TYPE, "text/plain")
            put(MediaStore.Files.FileColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/Quotify")
        }

        val uri = resolver.insert(MediaStore.Files.getContentUri("external"), contentValues)

        if (uri != null) {
            try {
                resolver.openOutputStream(uri).use { outputStream ->
                    outputStream?.write(textContent.toByteArray())
                    Toast.makeText(context, "Text file saved to Documents/Quotify", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Error saving text: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Failed to create text file", Toast.LENGTH_SHORT).show()
        }
    }



}
