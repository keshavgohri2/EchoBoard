package com.vms.quotify

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.SnapHelper
import com.vms.quotify.adapter.BlogAdapter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MainActivity : AppCompatActivity() {
    private lateinit var add: ImageView
    private lateinit var next: TextView
    private lateinit var previous: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BlogAdapter
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var logout : ImageView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var sharedPref: SharedPreferences
    private var blogs: MutableList<Blog> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        add = findViewById(R.id.img_add)
        next = findViewById(R.id.txt_next)
        previous = findViewById(R.id.txt_previous)
        recyclerView = findViewById(R.id.recycler_view)
        logout = findViewById(R.id.img_logout)

        sharedPref = getSharedPreferences("login_pref", MODE_PRIVATE)

        logout.setOnClickListener {
            // Clear login state
            with(sharedPref.edit()) {
                clear()
                apply()
            }

            // Redirect to LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        sharedPreferences = getSharedPreferences("BlogPrefs", Context.MODE_PRIVATE)
        blogs = loadBlogs()

        if (blogs.isEmpty()) {
            blogs.add(Blog("The Future of AI", "John Doe", R.drawable.baseline_format_quote_24))
        }

        // Set up horizontal RecyclerView
        layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.layoutManager = layoutManager
        adapter = BlogAdapter(blogs) { position -> deleteBlog(position) } // Pass delete function
        recyclerView.adapter = adapter

        // Add snapping effect
        val snapHelper: SnapHelper = LinearSnapHelper()
        snapHelper.attachToRecyclerView(recyclerView)

        // Handle Next Button Click
        next.setOnClickListener {
            val nextPosition = layoutManager.findFirstVisibleItemPosition() + 1
            if (nextPosition < blogs.size) {
                recyclerView.smoothScrollToPosition(nextPosition)
            }
        }

        // Handle Previous Button Click
        previous.setOnClickListener {
            val prevPosition = layoutManager.findFirstVisibleItemPosition() - 1
            if (prevPosition >= 0) {
                recyclerView.smoothScrollToPosition(prevPosition)
            }
        }

        // Open Custom Alert Dialog to Add a New Blog
        add.setOnClickListener {
            openAddBlogDialog()
        }
    }

    private fun deleteBlog(position: Int) {
        blogs.removeAt(position)
        adapter.notifyItemRemoved(position)
        saveBlogs()
    }

    private fun openAddBlogDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_blog, null)
        val dialogBuilder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)

        val alertDialog = dialogBuilder.create()
        alertDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        alertDialog.show()

        val editTitle = dialogView.findViewById<EditText>(R.id.edit_blog)
        val editAuthor = dialogView.findViewById<EditText>(R.id.edit_author)
        val btnAdd = dialogView.findViewById<Button>(R.id.btn_add)

        btnAdd.setOnClickListener {
            val title = editTitle.text.toString().trim()
            val author = editAuthor.text.toString().trim()

            if (title.isNotEmpty() && author.isNotEmpty()) {
                val newBlog = Blog(title, author, R.drawable.baseline_format_quote_24)
                blogs.add(newBlog)
                adapter.notifyItemInserted(blogs.size - 1)
                saveBlogs()
                alertDialog.dismiss()
            }
        }
    }

    private fun saveBlogs() {
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(blogs)
        editor.putString("blogs_list", json)
        editor.apply()
    }

    private fun loadBlogs(): MutableList<Blog> {
        val gson = Gson()
        val json = sharedPreferences.getString("blogs_list", null)
        val type = object : TypeToken<MutableList<Blog>>() {}.type
        return gson.fromJson(json, type) ?: mutableListOf()
    }
}
