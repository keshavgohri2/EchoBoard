package com.vms.quotify


data class Blog(
    val title: String,
    val author: String,
    val imageResId: Int // Resource ID for the blog icon
)
